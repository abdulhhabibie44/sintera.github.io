<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-10 07:30:28 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:30:30 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:30:32 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:33:33 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:33:37 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:33:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\xampp\htdocs\core\admindek\core_admindek\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-02-10 07:33:44 --> Unable to connect to the database
ERROR - 2022-02-10 07:34:02 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:34:02 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:34:03 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:34:04 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:35:08 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:35:10 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:35:12 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:36:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\xampp\htdocs\core\admindek\core_admindek\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-02-10 07:36:31 --> Unable to connect to the database
ERROR - 2022-02-10 07:36:36 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:37:59 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:38:02 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:38:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away C:\xampp\htdocs\core\admindek\core_admindek\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-02-10 07:38:10 --> Unable to connect to the database
ERROR - 2022-02-10 07:38:37 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:38:38 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:39:25 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:39:27 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:39:34 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:41:52 --> Severity: Error --> Maximum execution time of 120 seconds exceeded C:\xampp\htdocs\core\admindek\core_admindek\system\database\drivers\mysqli\mysqli_driver.php 275
ERROR - 2022-02-10 07:43:14 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:43:15 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:43:23 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:43:32 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:43:34 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:43:38 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:45:27 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:45:29 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:45:32 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:48:18 --> 404 Page Not Found: /index
ERROR - 2022-02-10 07:54:00 --> 404 Page Not Found: /index
