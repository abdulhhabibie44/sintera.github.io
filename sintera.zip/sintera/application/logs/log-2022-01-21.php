<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-21 12:14:59 --> Severity: 8192 --> strpos(): Non-string needles will be interpreted as strings in the future. Use an explicit chr() call to preserve the current behavior C:\xampp\htdocs\core_admindek\application\third_party\MX\Router.php 239
ERROR - 2022-01-21 12:14:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) C:\xampp\htdocs\core_admindek\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-01-21 12:14:59 --> Unable to connect to the database
ERROR - 2022-01-21 12:15:16 --> Severity: 8192 --> strpos(): Non-string needles will be interpreted as strings in the future. Use an explicit chr() call to preserve the current behavior C:\xampp\htdocs\core_admindek\application\third_party\MX\Router.php 239
ERROR - 2022-01-21 12:15:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) C:\xampp\htdocs\core_admindek\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2022-01-21 12:15:16 --> Unable to connect to the database
ERROR - 2022-01-21 12:16:04 --> Severity: 8192 --> strpos(): Non-string needles will be interpreted as strings in the future. Use an explicit chr() call to preserve the current behavior C:\xampp\htdocs\core_admindek\application\third_party\MX\Router.php 239
ERROR - 2022-01-21 12:18:05 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:18:05 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:18:05 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:18:05 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:18:05 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:18:05 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:18:05 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:18:05 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:18:05 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:18:05 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:18:05 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:18:05 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:18:05 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:18:05 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:21:57 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:21:57 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:21:57 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:21:57 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:21:57 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:22:02 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:22:02 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:22:02 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:22:02 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:22:02 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:22:03 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:22:03 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:22:03 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:22:03 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:22:03 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:22:04 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:22:04 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:22:04 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:22:04 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:22:04 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:23:17 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:23:17 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:23:17 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:23:17 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:23:17 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:23:17 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:23:17 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:23:20 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:23:21 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:24:06 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:24:06 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:24:06 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:24:06 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:24:06 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:24:06 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:25:05 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:25:05 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:25:05 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:25:05 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:25:05 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:25:22 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:25:22 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:25:22 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:25:22 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:25:56 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:25:56 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:25:56 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:25:56 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:26:53 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:26:57 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:27:01 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:30:40 --> 404 Page Not Found: /index
ERROR - 2022-01-21 12:30:44 --> 404 Page Not Found: /index
