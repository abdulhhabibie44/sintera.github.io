<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-21 09:36:54 --> Severity: error --> Exception: Class 'Jenssegers\Date\Date' not found C:\xampp\htdocs\ci\application\core\MY_Controller.php 22
ERROR - 2018-10-21 09:38:46 --> Severity: error --> Exception: Class 'Jenssegers\Date\Date' not found C:\xampp\htdocs\ci\application\core\MY_Controller.php 22
ERROR - 2018-10-21 09:42:52 --> Unable to load the requested class: Ion_auth
