<!-- metahaed -->
<?php $this->load->view('pages/v-metahead') ?>
<!-- custom -->
<?php empty($header_custom) ? '' : $this->load->view($header_custom); ?>
<!-- header & nav -->
<?php $this->load->view('pages/v-navigasi') ?>
<?php $this->load->view('pages/v-header') ?>

<!-- view content -->
<?php echo $view_content; ?>
<!-- footer -->
<?php $this->load->view('pages/v-footer') ?>
<!-- custom -->
<?php empty($footer_custom) ? '' : $this->load->view($footer_custom); ?>
<!-- footer end-->
<?php $this->load->view('pages/v-footer-end') ?>