				<!-- footer @s -->
				<div class="nk-footer">
					<div class="container-fluid">
						<div class="nk-footer-wrap">
							<div class="nk-footer-copyright"> &copy; <?= date("Y") ?> Sintera. Template by <a href="https://softnio.com" target="_blank">Softnio</a>
							</div>
						</div>
					</div>
				</div>
				<!-- footer @e -->
				</div>
				<!-- wrap @e -->
				</div>
				<!-- main @e -->
				</div>
				<script src="<?= base_url('_assets/js/bundle.js?ver=2.9.0') ?>"></script>
				<script src="<?= base_url('_assets/js/scripts.js?ver=2.9.0') ?>"></script>