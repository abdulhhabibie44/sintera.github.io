<!-- content @s -->
<div class="nk-content ">
	<div class="container-fluid">
		<div class="nk-content-inner">
			<div class="nk-content-body">
				<p>Starter page for demo2 layout.</p>
			</div>
		</div>
	</div>
</div>
<!-- content @e -->