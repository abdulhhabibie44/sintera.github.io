<!-- content @s -->
<div class="nk-content ">
	<div class="container-fluid">
		<div class="nk-content-inner">
			<div class="card mb-3">
				<div class="card-inner">

					<nav>
						<ul class="breadcrumb breadcrumb-arrow">
							<li class="breadcrumb-item"><a href="#">Manajemen PMKS</a></li>
							<li class="breadcrumb-item active">Data PMKS</li>
						</ul>
					</nav>
				</div>
			</div>
			<div class="nk-content-body">
				<div class="nk-block-head nk-block-head-sm">
					<div class="nk-block-between">
						<div class="nk-block-head-content">
							<h3 class="nk-block-title page-title">Manajemen Data PMKS</h3>
						</div><!-- .nk-block-head-content -->
						<div class="nk-block-head-content">
							<div class="toggle-wrap nk-block-tools-toggle">
								<a href="#" class="btn btn-icon btn-trigger toggle-expand mr-n1" data-target="pageMenu"><em class="icon ni ni-more-v"></em></a>
								<div class="toggle-expand-content" data-content="pageMenu">
									<ul class="nk-block-tools g-3">
										<li class="nk-block-tools-opt">
											<button type="button" data-toggle="modal" data-target="#add-form" class="btn btn-icon btn-primary d-md-none"><em class="icon ni ni-plus"></em><span>Tambah PMKS</span></button>
											<button type="button" data-toggle="modal" data-target="#add-form" class="toggle btn btn-primary d-none d-md-inline-flex"><em class="icon ni ni-plus"></em><span>Tambah PMKS</span></button>
										</li>
									</ul>
								</div>
							</div>
						</div><!-- .nk-block-head-content -->
					</div><!-- .nk-block-between -->
				</div><!-- .nk-block-head -->
				<div class="nk-block">
					<div class="card card-bordered">
						<div class="card-inner">
							<table class="datatable-init table">
								<thead>
									<tr>
										<th>No</th>
										<th>Nama</th>
										<th>Alamat</th>
										<th>Jenis Kelamin</th>
										<th>Jenis PMKS</th>
										<th>Status</th>
										<th>Aksi</th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td>1</td>
										<td>System Architect <br>123456789912912</td>
										<td>Edinburgh</td>
										<td>Edinburgh</td>
										<td>Edinburgh</td>
										<td><span class="badge badge-pill badge-dim badge-outline-warning">Menunggu Verifikasi</span></td>
										<td>
											<div class="drodown">
												<a href="#" class="btn btn-sm btn-icon btn-trigger dropdown-toggle" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
												<div class="dropdown-menu dropdown-menu-right">
													<ul class="link-list-opt no-bdr">
														<li><a href="#" data-toggle="modal" data-target="#edit-form"><em class="icon ni ni-edit text-warning"></em><span>Edit</span></a></li>
														<li><a href="#"><em class="icon ni ni-trash text-danger"></em><span>Hapus</span></a></li>
														<li class="divider"></li>
														<li><a href="#"><em class="icon ni ni-check text-success"></em><span>Verifikasi</span></a></li>
														<li><a href="#"><em class="icon ni ni-na text-danger"></em><span>Tolak Verifikasi</span></a></li>
													</ul>
												</div>
											</div>
										</td>
									</tr>
									<tr>
										<td>2</td>
										<td>System Architect <br>123456789912912</td>
										<td>Edinburgh</td>
										<td>Edinburgh</td>
										<td>Edinburgh</td>
										<td><span class="badge badge-pill badge-dim badge-outline-success">Disetujui</span></td>
										<td>
											<div class="drodown">
												<a href="#" class="btn btn-sm btn-icon btn-trigger dropdown-toggle" data-toggle="dropdown"><em class="icon ni ni-more-h"></em></a>
												<div class="dropdown-menu dropdown-menu-right">
													<ul class="link-list-opt no-bdr">
														<li><a href="#"><em class="icon ni ni-edit"></em><span>Edit</span></a></li>
														<li><a href="#"><em class="icon ni ni-trash"></em><span>Hapus</span></a></li>
													</ul>
												</div>
											</div>
										</td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
				</div><!-- .nk-block -->
			</div>
		</div>
	</div>
</div>
<?php $this->load->view('Pmks/extension/mdl-tambah-pmks'); ?>
<?php $this->load->view('Pmks/extension/mdl-edit-pmks'); ?>
<!-- content @e -->