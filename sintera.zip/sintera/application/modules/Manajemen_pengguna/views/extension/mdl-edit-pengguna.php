<!-- Modal Form -->
<div class="modal fade" id="edit-form">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Edit Pengguna</h5>
                <a href="#" class="close" data-dismiss="modal" aria-label="Close">
                    <em class="icon ni ni-cross"></em>
                </a>
            </div>
            <form action="#" class="form-validate is-alter">
                <div class="modal-body">
                    <div class="col-lg-12 border border-light" style="padding-top: 10px;">
                        <div class="row">
                            <div class="form-group col-lg-6 col-md-12 col-sm-6">
                                <label class="form-label" for="no-identitas">No Identitas</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="no-identitas" required>
                                </div>
                            </div>
                            <div class="form-group col-lg-6 col-md-12 col-sm-6">
                                <label class="form-label" for="nama">Nama Lengkap</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="nama" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-lg-6 col-md-12 col-sm-6">
                                <label class="form-label" for="username">Username</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="username" required>
                                </div>
                            </div>
                            <div class="form-group col-lg-6 col-md-12 col-sm-6">
                                <label class="form-label" for="password">Password</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="password" required>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="phone-no">Author</label>
                            <div class="form-control-wrap">
                                <select class="form-select" data-search="on">
                                    <option value="default_option">Default Option</option>
                                    <option value="option_select_name">Option select name</option>
                                    <option value="option_select_name">Option select name</option>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-lg-6 col-md-12 col-sm-6">
                                <label class="form-label" for="kecamatan">Kecamatan</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="kecamatan" required>
                                </div>
                            </div>
                            <div class="form-group col-lg-6 col-md-12 col-sm-6">
                                <label class="form-label" for="kelurahan">Kelurahan</label>
                                <div class="form-control-wrap">
                                    <input type="text" class="form-control" id="kelurahan" required>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <div class="form-group">
                        <button type="submit" class="btn btn-lg btn-primary">Simpan</button>
                        <button type="button" data-dismiss="modal" class="btn btn-lg btn-danger">Batal</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>