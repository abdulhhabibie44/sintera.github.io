<!-- content @s -->
<div class="nk-content ">
	<div class="container-fluid">
		<div class="nk-content-inner">
			<div class="card mb-3">
				<div class="card-inner">

					<nav>
						<ul class="breadcrumb breadcrumb-arrow">
							<li class="breadcrumb-item"><a href="#">Manajemen Pengguna</a></li>
							<li class="breadcrumb-item active">Profil</li>
						</ul>
					</nav>
				</div>
			</div>
			<div class="nk-content-body">
				<div class="nk-block">
					<div class="card">
						<div class="card-aside-wrap">
							<div class="card-inner">
								<div class="tab-content">
									<div class="tab-pane active" id="profil">
										<div class="nk-block-head">
											<div class="nk-block-between">
												<div class="nk-block-head-content">
													<h4 class="nk-block-title">Informasi Akun</h4>
												</div>
												<div class="nk-block-head-content align-self-start d-lg-none">
													<a href="#" class="toggle btn btn-icon btn-trigger mt-n1" data-target="userAside"><em class="icon ni ni-menu-alt-r"></em></a>
												</div>
											</div>
										</div><!-- .nk-block-head -->
										<div class="nk-block">
											<div class="nk-data data-list">
												<div class="data-head">
													<h6 class="overline-title">Informasi Detail Akun Pengguna</h6>
												</div>
												<div class="data-item">
													<div class="data-col">
														<span class="data-label">No Identitas</span>
														<span class="data-value">35141717187872</span>
													</div>
													<div class="data-col data-col-end"><span class="data-more"><em class="icon ni ni-forward-ios"></em></span></div>
												</div><!-- data-item -->
												<div class="data-item">
													<div class="data-col">
														<span class="data-label">Nama</span>
														<span class="data-value">Ishtiyak</span>
													</div>
													<div class="data-col data-col-end"><span class="data-more"><em class="icon ni ni-forward-ios"></em></span></div>
												</div><!-- data-item -->
												<div class="data-item">
													<div class="data-col">
														<span class="data-label">Username</span>
														<span class="data-value">Ishtiyak</span>
													</div>
													<div class="data-col data-col-end"><span class="data-more"><em class="icon ni ni-forward-ios"></em></span></div>
												</div><!-- data-item -->
												<div class="data-item">
													<div class="data-col">
														<span class="data-label">Author</span>
														<span class="badge badge-outline-primary">Ishtiyak</span>
													</div>
													<div class="data-col data-col-end"><span class="data-more"><em class="icon ni ni-forward-ios"></em></span></div>
												</div><!-- data-item -->
											</div><!-- data-list -->
										</div><!-- .nk-block -->
									</div>
									<div class="tab-pane" id="password">
										<div class="nk-block-head">
											<div class="nk-block-between">
												<div class="nk-block-head-content">
													<h4 class="nk-block-title">Password</h4>
												</div>
												<br>
												<div class="nk-block-des">
													<p class="text-danger">* Kosongi jika tidak merubah password.</p>
												</div>
												<div class="nk-block-head-content align-self-start d-lg-none">
													<a href="#" class="toggle btn btn-icon btn-trigger mt-n1" data-target="userAside"><em class="icon ni ni-menu-alt-r"></em></a>
												</div>
											</div>
										</div><!-- .nk-block-head -->
										<div class="nk-block">
											<div class="nk-data data-list">
												<div class="data-head">
													<h6 class="overline-title">Pastikan password lama dan baru sama</h6>
												</div>
												<div class="data-item">
													<div class="col-lg-12 border border-light" style="padding: 30px">
														<form action="#">
															<div class="form-group">
																<label class="form-label" for="pass-old">Password Lama</label>
																<div class="form-control-wrap">
																	<input type="text" class="form-control" id="pass-old">
																</div>
															</div>
															<div class="form-group">
																<label class="form-label" for="pass-old">Password Lama</label>
																<div class="form-control-wrap">
																	<input type="text" class="form-control" id="pass-old">
																</div>
															</div>
															<a href="#" class="btn btn-sm btn-primary"><span>Simpan</span> </a>
														</form>
													</div>
												</div><!-- data-item -->

											</div><!-- data-list -->
										</div><!-- .nk-block -->
									</div>
									<div class="tab-pane" id="log">
										<div class="nk-block-head">
											<div class="nk-block-between">
												<div class="nk-block-head-content">
													<h4 class="nk-block-title">History Akun</h4>
												</div>
												<div class="nk-block-head-content align-self-start d-lg-none">
													<a href="#" class="toggle btn btn-icon btn-trigger mt-n1" data-target="userAside"><em class="icon ni ni-menu-alt-r"></em></a>
												</div>
											</div>
										</div><!-- .nk-block-head -->
										<div class="nk-block">
											<div class="nk-data data-list">
												<div class="data-head">
													<h6 class="overline-title">Aktifitas akun selama diwebsite</h6>
												</div>
												<div class="data-item">
													<div class="table-responsive">
														<table class="datatable-init table">
															<thead>
																<tr>
																	<th>No</th>
																	<th>Kegiatan</th>
																	<th>Waktu</th>
																</tr>
															</thead>
															<tbody>
																<tr>
																	<td>1</td>
																	<td>System Architect</td>
																	<td>Edinburgh</td>
																</tr>
																<tr>
																	<td>2</td>
																	<td>Accountant</td>
																	<td>Tokyo</td>
																</tr>
																<tr>
																	<td>2</td>
																	<td>Junior Technical Author</td>
																	<td>San Francisco</td>
																</tr>
																<tr>
																	<td>3</td>
																	<td>Senior Javascript Developer</td>
																	<td>Edinburgh</td>
																</tr>
																<tr>
																	<td>3</td>
																	<td>Accountant</td>
																	<td>Tokyo</td>
																</tr>
																<tr>
																	<td>4</td>
																	<td>Integration Specialist</td>
																	<td>New York</td>
																</tr>
															</tbody>
														</table>
													</div>
												</div><!-- data-item -->

											</div><!-- data-list -->
										</div><!-- .nk-block -->
									</div>
								</div>
							</div>
							<div class="card-aside card-aside-left user-aside toggle-slide toggle-slide-left toggle-break-lg" data-content="userAside" data-toggle-screen="lg" data-toggle-overlay="true">
								<div class=" card-inner-group">
									<div class="card-inner">
										<div class="user-card">
											<div class="user-avatar bg-primary">
												<span>AB</span>
											</div>
											<div class="user-info">
												<span class="lead-text">Abu Bin Ishtiyak</span>
												<span class="sub-text">info@softnio.com</span>
											</div>
										</div><!-- .user-card -->
									</div><!-- .card-inner -->
									<div class="card-inner p-0">
										<ul class="nav link-list-menu round m-0">
											<li>
												<a class="active" data-toggle="tab" href="#profil"><em class="icon ni ni-user-fill-c"></em><span>Profil</span></a>
											</li>
											<li>
												<a data-toggle="tab" href="#password"><em class="icon ni ni-lock-alt-fill"></em><span>Password</span></a>
											</li>
											<li>
												<a data-toggle="tab" href="#log"><em class="icon ni ni-activity-round-fill"></em><span>Log Akun</span></a>
											</li>
										</ul>
									</div><!-- .card-inner -->
								</div><!-- .card-inner-group -->
							</div><!-- card-aside -->
						</div><!-- .card-aside-wrap -->
					</div><!-- .card -->
				</div><!-- .nk-block -->
			</div>
		</div>
	</div>
</div>
<!-- content @e -->