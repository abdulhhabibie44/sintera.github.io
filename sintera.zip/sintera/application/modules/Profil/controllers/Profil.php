<?php
if (!defined('BASEPATH'))
	exit('No direct script access allowed');

class Profil extends MY_Controller {

	function __construct()
	{
		parent::__construct();
		$this->module = $this->router->fetch_module();
		$this->isi = ['header_custom' => $this->module . '/v-header-custom', 'footer_custom' => $this->module . '/v-footer-custom'];
	}

	function index()
	{
		$data['page'] = 'Beranda';
				// $this->isi['module'] = $this->m_module->get_module();

		$this->isi['view_content']	= $this->load->view('v-content', '', TRUE);
				// var_dump($this->isi['view_content']);
		$this->load->view('pages/v-main', $this->isi);
	}
}
